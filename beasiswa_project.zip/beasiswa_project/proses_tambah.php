<?php
include 'koneksi.php';

$nama = $_POST['nama'];
$nim = $_POST['nim'];
$ipk = $_POST['ipk'];
$penghasilan = $_POST['penghasilan'];
$tanggungan = $_POST['tanggungan'];

$query = "INSERT INTO mahasiswa (nama, nim, ipk, penghasilan_ortu, tanggungan)
          VALUES ('$nama', '$nim', '$ipk', '$penghasilan', '$tanggungan')";

if (mysqli_query($conn, $query)) {
    header("Location: index.php");
} else {
    echo "Gagal menyimpan data: " . mysqli_error($conn);
}
?>
