<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mahasiswa</title>
</head>
<body>
    <h2>Form Tambah Mahasiswa</h2>
    <form action="proses_tambah.php" method="POST">
        <label>Nama:</label><br>
        <input type="text" name="nama"><br>
        <label>NIM:</label><br>
        <input type="text" name="nim"><br>
        <label>IPK:</label><br>
        <input type="text" name="ipk"><br>
        <label>Penghasilan Orang Tua:</label><br>
        <input type="text" name="penghasilan"><br>
        <label>Tanggungan:</label><br>
        <input type="text" name="tanggungan"><br><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
