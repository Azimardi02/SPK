<?php
include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM mahasiswa WHERE id = $id";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['submit'])) {
    $nama = $_POST['nama'];
    $nim = $_POST['nim'];
    $ipk = $_POST['ipk'];
    $penghasilan = $_POST['penghasilan_ortu'];
    $tanggungan = $_POST['tanggungan'];

    $update = "UPDATE mahasiswa SET 
                nama = '$nama', 
                nim = '$nim', 
                ipk = '$ipk', 
                penghasilan_ortu = '$penghasilan', 
                tanggungan = '$tanggungan' 
                WHERE id = $id";
    mysqli_query($conn, $update);

    echo "<script>alert('Data berhasil diupdate!'); window.location='index.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Edit Data Mahasiswa</h2>
    <form method="POST">
        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?= $data['nama'] ?>" required><br><br>

        <label>NIM:</label><br>
        <input type="text" name="nim" value="<?= $data['nim'] ?>" required><br><br>

        <label>IPK:</label><br>
        <input type="text" name="ipk" value="<?= $data['ipk'] ?>" required><br><br>

        <label>Penghasilan Ortu:</label><br>
        <input type="number" name="penghasilan_ortu" value="<?= $data['penghasilan_ortu'] ?>" required><br><br>

        <label>Tanggungan:</label><br>
        <input type="number" name="tanggungan" value="<?= $data['tanggungan'] ?>" required><br><br>

        <input type="submit" name="submit" value="Update">
        <a href="index.php">Batal</a>
    </form>
</body>
</html>
