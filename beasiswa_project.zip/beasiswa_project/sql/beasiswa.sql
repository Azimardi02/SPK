CREATE DATABASE IF NOT EXISTS beasiswa_db;
USE beasiswa_db;

CREATE TABLE mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    nim VARCHAR(20),
    ipk FLOAT,
    penghasilan_ortu INT,
    tanggungan INT
);

CREATE TABLE hasil_seleksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mahasiswa_id INT,
    skor FLOAT,
    status VARCHAR(20),
    FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id)
);
