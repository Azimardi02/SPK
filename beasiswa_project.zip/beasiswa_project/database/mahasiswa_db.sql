-- Buat database dan tabel
CREATE DATABASE IF NOT EXISTS mahasiswa_db;
USE mahasiswa_db;

CREATE TABLE IF NOT EXISTS mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    nim VARCHAR(20),
    ipk FLOAT,
    penghasilan_ortu INT,
    tanggungan INT
);

CREATE TABLE IF NOT EXISTS hasil_seleksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mahasiswa_id INT,
    skor FLOAT,
    status VARCHAR(20),
    FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id) ON DELETE CASCADE
);

-- Tambahkan 10 data mahasiswa
INSERT INTO mahasiswa (nama, nim, ipk, penghasilan_ortu, tanggungan) VALUES
('Ayu Putri', '20230001', 3.75, 3000000, 2),
('Budi Santoso', '20230002', 3.90, 2500000, 3),
('Citra Dewi', '20230003', 3.60, 4000000, 1),
('Dedi Kurniawan', '20230004', 3.95, 1500000, 4),
('Eka Lestari', '20230005', 3.70, 5000000, 2),
('Fajar Nugroho', '20230006', 3.80, 2000000, 3),
('Gina Salma', '20230007', 3.85, 1000000, 5),
('Hendra Wijaya', '20230008', 3.65, 4500000, 2),
('Intan Permata', '20230009', 3.88, 3000000, 1),
('Joko Widodo', '20230010', 3.92, 1200000, 6);

