<?php 
include 'koneksi.php';
$query = "SELECT * FROM mahasiswa ORDER BY ipk DESC";
$result = mysqli_query($conn, $query);
?>


<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>DATA MAHASISWA</h2>
    <a href="tambah.php" class="TD">+ Tambah Data</a>
    <table border="1" cellpadding="10">
        <tr>
            <th>Nama</th>
            <th>NIM</th>
            <th>IPK</th>
            <th>Penghasilan Ortu</th>
            <th>Tanggungan</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
        <tr>
            <td><?= $row['nama'] ?></td>
            <td><?= $row['nim'] ?></td>
            <td><?= $row['ipk'] ?></td>
            <td><?= $row['penghasilan_ortu'] ?></td>
            <td><?= $row['tanggungan'] ?></td>
            <td>
            <a href="edit_mahasiswa.php?id=<?= $row['id'] ?>">Edit</a> |
            <a href="hapus_mahasiswa.php?id=<?= $row['id'] ?>" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    
</body>
</html>
