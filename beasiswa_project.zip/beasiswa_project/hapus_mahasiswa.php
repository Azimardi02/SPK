<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $query = "DELETE FROM mahasiswa WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<script>
            alert('Data berhasil dihapus');
            window.location='index.php'; // ← ubah sesuai file yang ada
        </script>";
    } else {
        echo "<script>
            alert('Gagal menghapus data: " . mysqli_error($conn) . "');
            window.location='index.php';
        </script>";
    }
} else {
    echo "<script>
        alert('ID tidak ditemukan');
        window.location='index.php';
    </script>";
}
?>
